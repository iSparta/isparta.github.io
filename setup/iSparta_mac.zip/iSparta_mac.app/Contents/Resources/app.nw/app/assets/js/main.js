$(document).ready(function(){
	window.iSparta.init();
	// window.iSparta.apng.init();
	// window.iSparta.webp.init();
	// window.iSparta.imglossless.init();
	// window.iSparta.pngloss.init();
});